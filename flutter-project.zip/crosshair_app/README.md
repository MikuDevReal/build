# Crosshair Overlay App

Aplikasi crosshair overlay untuk game (PUBG, Free Fire, COD, dll) dengan fitur lengkap.

## Fitur

- **5 Warna**: Biru, Merah, Kuning, Hijau, Putih
- **5 Bentuk Crosshair**:
  1. Cross (+) klasik
  2. Dot (titik)
  3. Circle (lingkaran)
  4. Cross + Dot
  5. T Shape
- Atur **ukuran**, **ketebalan**, dan **kecerahan**
- Tombol **atas / bawah / kiri / kanan** untuk mengatur posisi
- Posisi vertikal dibatasi agar tidak naik terlalu tinggi (di atas kepala)
- Bisa di-**drag** langsung di overlay
- Tampilan **biru tua** dengan aksen **light blue**
- Permission **tampil di atas aplikasi lain** (SYSTEM_ALERT_WINDOW)

## Cara Build APK

1. Pastikan sudah install **Flutter SDK** (versi 3.x)
2. Buka terminal di folder project ini
3. Jalankan:

```bash
flutter pub get
flutter build apk --release
```

4. APK akan ada di: `build/app/outputs/flutter-apk/app-release.apk`

## Cara Pakai

1. Install APK di HP Android
2. Buka aplikasi → klik **"Berikan Izin Overlay"** → izinkan di Settings
3. Atur warna, bentuk, ukuran, ketebalan, kecerahan sesuai selera
4. Atur posisi dengan tombol panah
5. Klik **"Aktifkan Overlay"**
6. Buka game favoritmu — crosshair akan muncul di atas game
7. Drag crosshair untuk pindah posisi (posisi atas dibatasi otomatis)

## Catatan

- Minimal Android 6.0 (API 23)
- Harus izinkan "Display over other apps" / "Tampilkan di atas aplikasi lain"
- Setelah ubah setting, matikan lalu aktifkan ulang overlay agar perubahan diterapkan
