package com.example.crosshair_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
