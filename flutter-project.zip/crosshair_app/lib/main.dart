import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CrosshairApp());
}

// Entry point for the overlay
@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: CrosshairOverlay(),
  ));
}

class CrosshairApp extends StatelessWidget {
  const CrosshairApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Crosshair Overlay',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF0A1628),
        scaffoldBackgroundColor: const Color(0xFF0A1628),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF4FC3F7),
          secondary: Color(0xFF29B6F6),
          surface: Color(0xFF12253A),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0D1B2A),
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF1B3A4B),
            foregroundColor: const Color(0xFF4FC3F7),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isOverlayActive = false;
  bool _hasPermission = false;

  // Settings
  int _colorIndex = 0; // 0:biru, 1:merah, 2:kuning, 3:hijau, 4:putih
  double _brightness = 1.0;
  double _thickness = 2.0;
  double _size = 40.0;
  int _shapeIndex = 0; // 0:Cross, 1:Dot, 2:Circle, 3:Cross+Dot, 4:T
  double _posX = 0.5; // 0.0 - 1.0 relative
  double _posY = 0.5;

  final List<Color> _colors = [
    Colors.blue,
    Colors.red,
    Colors.yellow,
    Colors.green,
    Colors.white,
  ];

  final List<String> _colorNames = [
    'Biru',
    'Merah',
    'Kuning',
    'Hijau',
    'Putih',
  ];

  final List<String> _shapeNames = [
    'Cross (+)',
    'Dot (•)',
    'Circle (○)',
    'Cross + Dot',
    'T Shape',
  ];

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _checkPermission();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _colorIndex = prefs.getInt('colorIndex') ?? 0;
      _brightness = prefs.getDouble('brightness') ?? 1.0;
      _thickness = prefs.getDouble('thickness') ?? 2.0;
      _size = prefs.getDouble('size') ?? 40.0;
      _shapeIndex = prefs.getInt('shapeIndex') ?? 0;
      _posX = prefs.getDouble('posX') ?? 0.5;
      _posY = prefs.getDouble('posY') ?? 0.5;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('colorIndex', _colorIndex);
    await prefs.setDouble('brightness', _brightness);
    await prefs.setDouble('thickness', _thickness);
    await prefs.setDouble('size', _size);
    await prefs.setInt('shapeIndex', _shapeIndex);
    await prefs.setDouble('posX', _posX);
    await prefs.setDouble('posY', _posY);
  }

  Future<void> _checkPermission() async {
    final status = await FlutterOverlayWindow.isPermissionGranted();
    setState(() {
      _hasPermission = status;
    });
  }

  Future<void> _requestPermission() async {
    final status = await FlutterOverlayWindow.requestPermission();
    setState(() {
      _hasPermission = status ?? false;
    });
    if (!_hasPermission) {
      // Open settings if needed
      await openAppSettings();
    }
  }

  Future<void> _toggleOverlay() async {
    if (!_hasPermission) {
      await _requestPermission();
      if (!_hasPermission) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Izin overlay diperlukan!')),
        );
        return;
      }
    }

    if (_isOverlayActive) {
      await FlutterOverlayWindow.closeOverlay();
      setState(() {
        _isOverlayActive = false;
      });
    } else {
      await _saveSettings();
      await FlutterOverlayWindow.showOverlay(
        enableDrag: true,
        overlayTitle: "Crosshair",
        overlayContent: "Crosshair Overlay Active",
        flag: OverlayFlag.defaultFlag,
        visibility: NotificationVisibility.visibilityPublic,
        positionGravity: PositionGravity.none,
        height: (_size * 2 + 20).toInt().clamp(50, 300),
        width: (_size * 2 + 20).toInt().clamp(50, 300),
        startPosition: OverlayPosition(
          (_posX * 300 - 50).clamp(-200.0, 200.0),
          (_posY * 500 - 100).clamp(-300.0, 300.0),
        ),
      );
      setState(() {
        _isOverlayActive = true;
      });
    }
  }

  void _movePosition(String direction) {
    setState(() {
      const step = 0.03;
      switch (direction) {
        case 'left':
          _posX = (_posX - step).clamp(0.1, 0.9);
          break;
        case 'right':
          _posX = (_posX + step).clamp(0.1, 0.9);
          break;
        case 'up':
          // Limit so it doesn't go too high (above head area)
          _posY = (_posY - step).clamp(0.25, 0.85);
          break;
        case 'down':
          _posY = (_posY + step).clamp(0.25, 0.85);
          break;
      }
    });
    _saveSettings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Crosshair Overlay',
          style: TextStyle(
            color: Color(0xFF4FC3F7),
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0A1628),
              Color(0xFF12253A),
              Color(0xFF0D1B2A),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Status Card
                _buildCard(
                  child: Column(
                    children: [
                      Icon(
                        _isOverlayActive
                            ? Icons.visibility
                            : Icons.visibility_off,
                        size: 40,
                        color: _isOverlayActive
                            ? const Color(0xFF4FC3F7)
                            : Colors.grey,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _isOverlayActive
                            ? 'Overlay AKTIF'
                            : 'Overlay NONAKTIF',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: _isOverlayActive
                              ? const Color(0xFF4FC3F7)
                              : Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton.icon(
                        onPressed: _toggleOverlay,
                        icon: Icon(
                          _isOverlayActive ? Icons.stop : Icons.play_arrow,
                        ),
                        label: Text(
                          _isOverlayActive
                              ? 'Matikan Overlay'
                              : 'Aktifkan Overlay',
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _isOverlayActive
                              ? Colors.red.shade800
                              : const Color(0xFF1B3A4B),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                        ),
                      ),
                      if (!_hasPermission) ...[
                        const SizedBox(height: 8),
                        TextButton(
                          onPressed: _requestPermission,
                          child: const Text(
                            'Berikan Izin Overlay',
                            style: TextStyle(color: Color(0xFF4FC3F7)),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Color Selection
                _buildCard(
                  title: 'Warna Crosshair',
                  child: Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: List.generate(5, (index) {
                      final isSelected = _colorIndex == index;
                      return GestureDetector(
                        onTap: () {
                          setState(() => _colorIndex = index);
                          _saveSettings();
                        },
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: _colors[index],
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFF4FC3F7)
                                  : Colors.transparent,
                              width: 3,
                            ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: _colors[index].withOpacity(0.6),
                                      blurRadius: 8,
                                      spreadRadius: 2,
                                    )
                                  ]
                                : null,
                          ),
                          child: isSelected
                              ? const Icon(Icons.check, color: Colors.black54)
                              : null,
                        ),
                      );
                    }),
                  ),
                ),

                const SizedBox(height: 16),

                // Shape Selection
                _buildCard(
                  title: 'Bentuk Crosshair',
                  child: Column(
                    children: List.generate(5, (index) {
                      final isSelected = _shapeIndex == index;
                      return ListTile(
                        dense: true,
                        leading: Icon(
                          isSelected
                              ? Icons.radio_button_checked
                              : Icons.radio_button_off,
                          color: isSelected
                              ? const Color(0xFF4FC3F7)
                              : Colors.grey,
                        ),
                        title: Text(
                          _shapeNames[index],
                          style: TextStyle(
                            color: isSelected
                                ? const Color(0xFF4FC3F7)
                                : Colors.white70,
                          ),
                        ),
                        onTap: () {
                          setState(() => _shapeIndex = index);
                          _saveSettings();
                        },
                      );
                    }),
                  ),
                ),

                const SizedBox(height: 16),

                // Size, Thickness, Brightness
                _buildCard(
                  title: 'Pengaturan Ukuran & Ketebalan',
                  child: Column(
                    children: [
                      _buildSlider(
                        label: 'Ukuran',
                        value: _size,
                        min: 15,
                        max: 100,
                        onChanged: (v) {
                          setState(() => _size = v);
                          _saveSettings();
                        },
                      ),
                      _buildSlider(
                        label: 'Ketebalan',
                        value: _thickness,
                        min: 1,
                        max: 8,
                        onChanged: (v) {
                          setState(() => _thickness = v);
                          _saveSettings();
                        },
                      ),
                      _buildSlider(
                        label: 'Kecerahan',
                        value: _brightness,
                        min: 0.3,
                        max: 1.0,
                        onChanged: (v) {
                          setState(() => _brightness = v);
                          _saveSettings();
                        },
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Position Controls
                _buildCard(
                  title: 'Posisi Crosshair',
                  child: Column(
                    children: [
                      // Up
                      IconButton(
                        onPressed: () => _movePosition('up'),
                        icon: const Icon(Icons.keyboard_arrow_up, size: 40),
                        color: const Color(0xFF4FC3F7),
                      ),
                      // Left - Center - Right
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () => _movePosition('left'),
                            icon: const Icon(Icons.keyboard_arrow_left, size: 40),
                            color: const Color(0xFF4FC3F7),
                          ),
                          const SizedBox(width: 40),
                          IconButton(
                            onPressed: () => _movePosition('right'),
                            icon: const Icon(Icons.keyboard_arrow_right, size: 40),
                            color: const Color(0xFF4FC3F7),
                          ),
                        ],
                      ),
                      // Down
                      IconButton(
                        onPressed: () => _movePosition('down'),
                        icon: const Icon(Icons.keyboard_arrow_down, size: 40),
                        color: const Color(0xFF4FC3F7),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Posisi dibatasi agar tidak terlalu tinggi (di atas kepala)',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.white.withOpacity(0.5),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Preview
                _buildCard(
                  title: 'Preview Crosshair',
                  child: Container(
                    height: 150,
                    alignment: Alignment.center,
                    child: CustomPaint(
                      size: Size(_size * 2, _size * 2),
                      painter: CrosshairPainter(
                        color: _colors[_colorIndex].withOpacity(_brightness),
                        thickness: _thickness,
                        size: _size,
                        shapeIndex: _shapeIndex,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 24),
                Text(
                  'Tips: Setelah aktifkan overlay, drag crosshair untuk pindah posisi.\nPosisi vertikal dibatasi agar tidak naik terlalu tinggi.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white.withOpacity(0.4),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCard({String? title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF12253A).withOpacity(0.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFF1B3A4B),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null) ...[
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4FC3F7),
              ),
            ),
            const SizedBox(height: 12),
          ],
          child,
        ],
      ),
    );
  }

  Widget _buildSlider({
    required String label,
    required double value,
    required double min,
    required double max,
    required ValueChanged<double> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: Colors.white70)),
            Text(
              value.toStringAsFixed(1),
              style: const TextStyle(color: Color(0xFF4FC3F7)),
            ),
          ],
        ),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor: const Color(0xFF4FC3F7),
            inactiveTrackColor: const Color(0xFF1B3A4B),
            thumbColor: const Color(0xFF29B6F6),
            overlayColor: const Color(0xFF4FC3F7).withOpacity(0.2),
          ),
          child: Slider(
            value: value,
            min: min,
            max: max,
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }
}

// ==================== OVERLAY WIDGET ====================
class CrosshairOverlay extends StatefulWidget {
  const CrosshairOverlay({super.key});

  @override
  State<CrosshairOverlay> createState() => _CrosshairOverlayState();
}

class _CrosshairOverlayState extends State<CrosshairOverlay> {
  int _colorIndex = 0;
  double _brightness = 1.0;
  double _thickness = 2.0;
  double _size = 40.0;
  int _shapeIndex = 0;

  final List<Color> _colors = [
    Colors.blue,
    Colors.red,
    Colors.yellow,
    Colors.green,
    Colors.white,
  ];

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _colorIndex = prefs.getInt('colorIndex') ?? 0;
      _brightness = prefs.getDouble('brightness') ?? 1.0;
      _thickness = prefs.getDouble('thickness') ?? 2.0;
      _size = prefs.getDouble('size') ?? 40.0;
      _shapeIndex = prefs.getInt('shapeIndex') ?? 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Center(
        child: CustomPaint(
          size: Size(_size * 2, _size * 2),
          painter: CrosshairPainter(
            color: _colors[_colorIndex].withOpacity(_brightness),
            thickness: _thickness,
            size: _size,
            shapeIndex: _shapeIndex,
          ),
        ),
      ),
    );
  }
}

// ==================== PAINTER ====================
class CrosshairPainter extends CustomPainter {
  final Color color;
  final double thickness;
  final double size;
  final int shapeIndex;

  CrosshairPainter({
    required this.color,
    required this.thickness,
    required this.size,
    required this.shapeIndex,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = thickness
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final fillPaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final center = Offset(size.width / 2, size.height / 2);
    final half = this.size / 2;

    switch (shapeIndex) {
      case 0: // Classic Cross (+)
        // Horizontal
        canvas.drawLine(
          Offset(center.dx - half, center.dy),
          Offset(center.dx + half, center.dy),
          paint,
        );
        // Vertical
        canvas.drawLine(
          Offset(center.dx, center.dy - half),
          Offset(center.dx, center.dy + half),
          paint,
        );
        // Small gap in center (optional for better look)
        break;

      case 1: // Dot
        canvas.drawCircle(center, thickness * 1.5, fillPaint);
        break;

      case 2: // Circle
        canvas.drawCircle(center, half * 0.7, paint);
        // Optional center dot
        canvas.drawCircle(center, thickness, fillPaint);
        break;

      case 3: // Cross + Dot
        // Cross
        canvas.drawLine(
          Offset(center.dx - half, center.dy),
          Offset(center.dx - thickness * 2, center.dy),
          paint,
        );
        canvas.drawLine(
          Offset(center.dx + thickness * 2, center.dy),
          Offset(center.dx + half, center.dy),
          paint,
        );
        canvas.drawLine(
          Offset(center.dx, center.dy - half),
          Offset(center.dx, center.dy - thickness * 2),
          paint,
        );
        canvas.drawLine(
          Offset(center.dx, center.dy + thickness * 2),
          Offset(center.dx, center.dy + half),
          paint,
        );
        // Center dot
        canvas.drawCircle(center, thickness * 1.2, fillPaint);
        break;

      case 4: // T Shape
        // Horizontal top
        canvas.drawLine(
          Offset(center.dx - half, center.dy - half * 0.6),
          Offset(center.dx + half, center.dy - half * 0.6),
          paint,
        );
        // Vertical down
        canvas.drawLine(
          Offset(center.dx, center.dy - half * 0.6),
          Offset(center.dx, center.dy + half),
          paint,
        );
        break;
    }
  }

  @override
  bool shouldRepaint(covariant CrosshairPainter oldDelegate) {
    return oldDelegate.color != color ||
        oldDelegate.thickness != thickness ||
        oldDelegate.size != size ||
        oldDelegate.shapeIndex != shapeIndex;
  }
}
