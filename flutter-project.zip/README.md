# Crosshair Overlay — Fixed Build Layout

This version removes all `ic_launcher.*` and `ic_launcher_round.*` resource duplicates from the project.
The manifest still references `@mipmap/ic_launcher`; generate launcher icons with your build environment
(or replace the reference with your own single icon resource).

## Clean build
```bash
flutter clean
flutter pub get
flutter build apk --release
```

If your build service supplies its own Flutter build command, use that command rather than `./gradlew`.

The app is a visual-only crosshair overlay. It does not auto-aim, track targets, capture the screen,
read game memory, or inject touch/input events.
