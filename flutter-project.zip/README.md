# Prank Flash — Flutter

Isi proyek:
- `lib/main.dart`
- `pubspec.yaml`
- `assets/prank.jpg`
- `assets/mbg.mp3`
- `android/app/src/main/AndroidManifest.xml` (permission kamera untuk torch)

Perilaku:
- Menampilkan foto yang diberikan.
- Tombol MULAI menjalankan audio dan flash secara berkala.
- Tombol HENTIKAN menghentikan semuanya.
- Tombol Back Android juga menghentikan semuanya sebelum keluar.
- Tidak meminta izin audio/mikrofon/lokasi.
- Tidak mengunci volume sistem dan tidak memaksa volume tetap tinggi.

Catatan keselamatan:
Flash dibuat dengan interval moderat, bukan strobe ekstrem. Jangan arahkan flash ke mata atau gunakan pada orang yang sensitif terhadap cahaya.

Build:
1. Pastikan Flutter SDK terpasang.
2. Jalankan `flutter create --platforms=android .` dari folder proyek ini agar file Android/Gradle standar dibuat.
3. Jalankan `flutter pub get`.
4. Jalankan `flutter build apk --release`.

Jika `flutter create` menanyakan penggantian file, pertahankan `lib/main.dart`, `pubspec.yaml`, asset, dan permission `CAMERA` di Manifest.
