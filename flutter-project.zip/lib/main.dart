import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:torch_light/torch_light.dart';

void main() {
  runApp(const PrankApp());
}

class PrankApp extends StatelessWidget {
  const PrankApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Prank Flash',
      theme: ThemeData.dark(useMaterial3: true),
      home: const PrankHome(),
    );
  }
}

class PrankHome extends StatefulWidget {
  const PrankHome({super.key});

  @override
  State<PrankHome> createState() => _PrankHomeState();
}

class _PrankHomeState extends State<PrankHome> {
  final AudioPlayer _player = AudioPlayer();
  Timer? _timer;
  bool _running = false;
  bool _torchOn = false;

  // Deliberately moderate blinking interval rather than an extreme strobe.
  static const Duration blinkInterval = Duration(milliseconds: 450);

  @override
  void dispose() {
    _stopPrank();
    _player.dispose();
    super.dispose();
  }

  Future<void> _setTorch(bool value) async {
    try {
      if (value) {
        await TorchLight.enableTorch();
      } else {
        await TorchLight.disableTorch();
      }
      _torchOn = value;
    } catch (_) {
      _torchOn = false;
    }
  }

  Future<void> _startPrank() async {
    if (_running) return;

    setState(() => _running = true);

    await _setTorch(true);
    await _player.setReleaseMode(ReleaseMode.loop);
    // The app does not force or lock system volume.
    await _player.play(AssetSource('mbg.mp3'), volume: 1.0);

    _timer = Timer.periodic(blinkInterval, (_) async {
      if (!_running) return;
      await _setTorch(!_torchOn);
      if (mounted) setState(() {});
    });

    if (mounted) setState(() {});
  }

  Future<void> _stopPrank() async {
    _timer?.cancel();
    _timer = null;
    _running = false;

    await _player.stop();
    await _setTorch(false);

    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        await _stopPrank();
        return true;
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('Prank Flash')),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'assets/prank.jpg',
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    _running ? 'PRANK AKTIF' : 'Tekan MULAI',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Tombol kembali selalu menghentikan suara dan flash.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 22),
                  FilledButton.icon(
                    onPressed: _running ? _stopPrank : _startPrank,
                    icon: Icon(_running ? Icons.stop : Icons.flash_on),
                    label: Text(_running ? 'HENTIKAN' : 'MULAI PRANK'),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Catatan: aplikasi tidak mengunci volume sistem dan tidak mencegah pengguna menurunkannya.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
