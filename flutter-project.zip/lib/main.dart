import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

void main() => runApp(const CrosshairApp());

const colors = [
  Color(0xFF2196F3),
  Color(0xFFF44336),
  Color(0xFFFFEB3B),
  Color(0xFF4CAF50),
  Color(0xFFFFFFFF),
];

class CrosshairApp extends StatefulWidget {
  const CrosshairApp({super.key});
  @override
  State<CrosshairApp> createState() => _CrosshairAppState();
}

class _CrosshairAppState extends State<CrosshairApp> {
  int colorIndex = 0;
  double opacity = 1, thickness = 3, size = 52;
  int shape = 0;
  double x = 0, y = 0;

  Future<void> openOverlay() async {
    if (!await FlutterOverlayWindow.isPermissionGranted()) {
      await FlutterOverlayWindow.requestPermission();
    }
    if (await FlutterOverlayWindow.isPermissionGranted()) {
      await FlutterOverlayWindow.showOverlay(
        enableDrag: true,
        overlayTitle: 'Crosshair',
        overlayContent: 'Visual Crosshair',
        flag: OverlayFlag.defaultFlag,
        alignment: OverlayAlignment.center,
        visibility: NotificationVisibility.visibilityPublic,
        positionGravity: PositionGravity.none,
      );
      await send();
    }
  }

  Future<void> send() async {
    try {
      await FlutterOverlayWindow.shareData({
        'color': colors[colorIndex].value,
        'opacity': opacity,
        'thickness': thickness,
        'size': size,
        'shape': shape,
        'x': x,
        'y': y,
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF071426),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF42A5F5),
          brightness: Brightness.dark,
        ),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Crosshair Overlay'),
          backgroundColor: const Color(0xFF0B2340),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Warna', style: TextStyle(fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 8,
              children: List.generate(colors.length, (i) {
                return ChoiceChip(
                  label: Text(['Biru','Merah','Kuning','Hijau','Putih'][i]),
                  selected: colorIndex == i,
                  onSelected: (_) { setState(() => colorIndex = i); send(); },
                );
              }),
            ),
            _slider('Kecerahan / Opacity', opacity, .1, 1,
                (v) { setState(() => opacity = v); send(); }),
            _slider('Ketebalan', thickness, 1, 8,
                (v) { setState(() => thickness = v); send(); }),
            _slider('Ukuran', size, 18, 100,
                (v) { setState(() => size = v); send(); }),
            const SizedBox(height: 8),
            const Text('Bentuk', style: TextStyle(fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 8,
              children: List.generate(5, (i) {
                return ChoiceChip(
                  label: Text('Bentuk ${i+1}'),
                  selected: shape == i,
                  onSelected: (_) { setState(() => shape = i); send(); },
                );
              }),
            ),
            const SizedBox(height: 16),
            const Text('Posisi'),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: () { setState(() => y -= 10); send(); }, icon: const Icon(Icons.keyboard_arrow_up)),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: () { setState(() => x -= 10); send(); }, icon: const Icon(Icons.keyboard_arrow_left)),
                IconButton(onPressed: () { setState(() { x = 0; y = 0; }); send(); }, icon: const Icon(Icons.my_location)),
                IconButton(onPressed: () { setState(() => x += 10); send(); }, icon: const Icon(Icons.keyboard_arrow_right)),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: () { setState(() => y += 10); send(); }, icon: const Icon(Icons.keyboard_arrow_down)),
              ],
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: openOverlay,
              icon: const Icon(Icons.layers),
              label: const Text('Izinkan & Tampilkan Crosshair'),
            ),
            const SizedBox(height: 8),
            OutlinedButton(
              onPressed: () => FlutterOverlayWindow.closeOverlay(),
              child: const Text('Tutup Crosshair'),
            ),
            const SizedBox(height: 12),
            const Text(
              'Catatan: overlay ini hanya visual. Tidak melakukan auto-aim, membaca memori game, screen capture, atau input injection.',
              style: TextStyle(color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }

  Widget _slider(String title, double value, double min, double max, ValueChanged<double> fn) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$title: ${value.toStringAsFixed(1)}'),
        Slider(value: value, min: min, max: max, onChanged: fn),
      ],
    );
  }
}

@pragma('vm:entry-point')
void overlayMain() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      backgroundColor: Colors.transparent,
      body: Center(child: _Crosshair()),
    ),
  ));
}

class _Crosshair extends StatelessWidget {
  const _Crosshair();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(64, 64),
      painter: _CrosshairPainter(),
    );
  }
}

class _CrosshairPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = const Color(0xFF42A5F5)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;
    final c = Offset(size.width/2, size.height/2);
    canvas.drawLine(Offset(c.dx-24,c.dy), Offset(c.dx+24,c.dy), p);
    canvas.drawLine(Offset(c.dx,c.dy-24), Offset(c.dx,c.dy+24), p);
    canvas.drawCircle(c, 5, p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
