import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

class SplashVideoPage extends StatefulWidget {
  final Widget nextPage;

  const SplashVideoPage({super.key, required this.nextPage});

  @override
  State<SplashVideoPage> createState() => _SplashVideoPageState();
}

class _SplashVideoPageState extends State<SplashVideoPage>
    with TickerProviderStateMixin {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  bool _skipPressed = false;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  Timer? _timeoutTimer;

  final Color _primaryColor = const Color(0xFF050810);
  final Color _textColor = const Color(0xFFEEF2FF);
  final Color _accentColor = const Color(0xFF00D4FF);

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeVideo();

    _timeoutTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && !_skipPressed && !_isInitialized) {
        _navigateToNextPage();
      }
    });
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOutCubic),
    );
    _fadeController.forward();
  }

  void _initializeVideo() {
    _controller = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        if (mounted) {
          SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
          setState(() => _isInitialized = true);
          _controller.play();
          _controller.setVolume(1);
        }
      }).catchError((error) {
        debugPrint("Video initialization error: $error");
        if (mounted) {
          setState(() => _isInitialized = true);
          Future.delayed(const Duration(seconds: 1), _navigateToNextPage);
        }
      });

    _controller.addListener(() {
      if (mounted && _controller.value.isInitialized) {
        if (_controller.value.position >= _controller.value.duration) {
          _navigateToNextPage();
        }
      }
    });
  }

  void _navigateToNextPage() {
    if (_skipPressed) return;
    _skipPressed = true;

    _timeoutTimer?.cancel();
    _controller.pause();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => widget.nextPage),
      );
    }
  }

  void _skipVideo() {
    if (_skipPressed) return;
    _fadeController.reverse().then((_) {
      _navigateToNextPage();
    });
  }

  @override
  void dispose() {
    _timeoutTimer?.cancel();
    _controller.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  Widget _buildBaseLayer() {
    if (_isInitialized && _controller.value.isInitialized) {
      return SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _controller.value.size.width,
            height: _controller.value.size.height,
            child: Opacity(opacity: 0.65, child: VideoPlayer(_controller)),
          ),
        ),
      );
    }
    return Container(color: _primaryColor);
  }

  Widget _buildSkipButton() {
    return Positioned(
      top: 20, // <-- Dinaikkan dari 52 menjadi 20 agar lebih ke atas
      right: 20,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: GestureDetector(
          onTap: _skipVideo,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.55),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _accentColor.withOpacity(0.4), width: 1.2),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("LEWATI",
                  style: TextStyle(
                    color: _textColor.withOpacity(0.8),
                    fontWeight: FontWeight.w500,
                    fontSize: 11,
                    letterSpacing: 2,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const SizedBox(width: 6),
                Icon(Icons.fast_forward_rounded, color: _accentColor, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _primaryColor,
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBaseLayer(),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.15),
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withOpacity(0.55),
                  ],
                  stops: const [0.0, 0.25, 0.65, 1.0],
                ),
              ),
            ),
          ),
          _buildSkipButton(),
          Center(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 1,
                    height: 40,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          _accentColor.withOpacity(0.7),
                        ],
                      ),
                    ),
                    margin: const EdgeInsets.only(bottom: 24),
                  ),
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [
                        _textColor,
                        _accentColor,
                        _textColor,
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ).createShader(bounds),
                    child: Text(
                      "Vxz Cr4sher",
                      style: TextStyle(
                        fontSize: 58,
                        fontWeight: FontWeight.w300,
                        fontFamily: 'Orbitron',
                        letterSpacing: 14,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: _accentColor.withOpacity(0.6),
                            blurRadius: 30,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    "Hanya Untuk Bersenang - Senang",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.25),
                      fontSize: 10,
                      letterSpacing: 6,
                      fontFamily: 'Rajdhani',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Container(
                    width: 80,
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          _accentColor.withOpacity(0.5),
                          Colors.transparent,
                        ],
                      ),
                    ),
                    margin: const EdgeInsets.only(top: 28),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}