# Perbaikan Gradle 8.7 + AGP 8.6

Error `The daemon has disappeared unexpectedly` pada log terjadi tanpa stacktrace Gradle;
daemon berhenti tepat saat mulai eksekusi build. Log menunjukkan JVM daemon mendapat
`-Xmx4g`, yang sangat berisiko membuat worker/VPS terkena OOM kill.

Perubahan utama:
- Gradle JVM dibatasi ke 1 GB + MaxMetaspace 256 MB.
- `org.gradle.daemon=false`, worker 1, parallel off.
- Kotlin compiler dijalankan in-process agar tidak membuat JVM daemon tambahan.
- Cache `.gradle` hasil build dihapus dari ZIP supaya environment CI membuat cache baru
  yang sesuai dengan wrapper Gradle 8.7.
- Versi Gradle wrapper tetap 8.7 dan AGP tetap 8.6.0.

Build:
`flutter clean`
`flutter pub get`
`flutter build apk --release`

Catatan: jika platform CI memaksa `-Xmx4g` melalui command-line/system property,
pengaturan `org.gradle.jvmargs` di project dapat ditimpa oleh platform. Dalam kasus itu,
runner harus menurunkan JVM heap dari konfigurasi worker/CI juga.
