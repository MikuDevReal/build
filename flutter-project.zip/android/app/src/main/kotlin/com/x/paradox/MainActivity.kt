package com.x.paradox

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.x.paradox/floating_bagger"
    
    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "startFloatingService" -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (Settings.canDrawOverlays(this)) {
                                val intent = Intent(this, FloatingBaggerService::class.java)
                                intent.putExtra("username", call.argument<String>("username"))
                                intent.putExtra("password", call.argument<String>("password"))
                                intent.putExtra("sessionKey", call.argument<String>("sessionKey"))
                                intent.putExtra("role", call.argument<String>("role"))
                                intent.putExtra("expiredDate", call.argument<String>("expiredDate"))
                                
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    startForegroundService(intent)
                                } else {
                                    startService(intent)
                                }
                                result.success(true)
                            } else {
                                result.error("PERMISSION_DENIED", "Izin overlay tidak diberikan", null)
                            }
                        }
                    }
                    "stopFloatingService" -> {
                        val intent = Intent(this, FloatingBaggerService::class.java)
                        stopService(intent)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}